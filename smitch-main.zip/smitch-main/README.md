# smitch
smitch

To Run Locally:

make sure port 3000, 6379, 8000 and 27017 are not use.

make build                                                                                   
make run                                                                                   

To Run on Remote Host:

First change the base url used in Frontend:

cd frontend/client/api                                                                  
vi index.js                                                                         

// Update the baseURL url with your server url


Backend:- 

Postman collection: 

Link: https://www.getpostman.com/collections/905b3633c4ae2940d525

API Doc: https://documenter.getpostman.com/view/7504276/Tz5jffxL

Please Set these Environment Variables in Postman: 

url = http://3.86.39.139:8000
auth = Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYwNDQ1ZThjMTBlYTQ3MDAxMzhjNDc1OSIsImlhdCI6MTYxNTA5NjY0NSwiZXhwIjoxNzAxNDk2NjQ1fQ.qBRou7e9ZpaEGDiM4DBUAdNqwI7Nhquu0OwzZ4M7eEk

Redis Cache is enabled. persistence of the data is set to 60 Seconds

Devices can be shared with other users, Using share button.
