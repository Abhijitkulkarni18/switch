const redis = require('redis');

const client = redis.createClient({
  port      : 6379,
  host      : 'redis'
});

exports.cache = (req, res, next) => {
  
    client.get( req.user.id, (err, data) => {
      if (err) throw err;
  
      if (data !== null) {
        console.log('data from redis')
        res.status(200).json({
            success: true,
            devices: JSON.parse(data)
        })
      } else {
        next();
      }
    });
  }