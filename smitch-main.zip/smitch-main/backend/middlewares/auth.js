const User = require('../models/user');

const jwt = require("jsonwebtoken");
const ErrorHandler = require("../utils/errorHandler");
const catchAsyncErrors = require("./catchAsyncErrors");

exports.isAuthenticatedUser = catchAsyncErrors(async (req, res, next) => {
    const bearerHeader = req.headers['authorization'];

    if (bearerHeader) {
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        token = bearerToken;
    } else {
        return next(new ErrorHandler('Forbidden. authorization needed', 401))
    }
    if (!token) {
        return next(new ErrorHandler('Login first to access this resource.', 401))
    }
    const decoded = jwt.verify(token, 'jnsdcdjcnjwncwjnjvervjevjervjerjvne')
    req.user = await User.findById(decoded.id);
    if (!req.user)
        return next(new ErrorHandler('Forbidden. authorization needed', 401))
    next()
})