const express = require('express');
const app = express();
const helmet = require('helmet');
const cors = require('cors');
const errorMiddleware = require('./middlewares/errors')


app.use(express.json());
app.use(helmet());
app.use(cors());

const user = require('./routes/user.js')
const device = require('./routes/device.js')

app.use('/api', user)
app.use('/api', device)

app.use('*', function(req, res) {
  res.status(400).json({
    message: 'API you tried to access does not exist with us. Retry to another route'
  })
});
app.use(errorMiddleware);

module.exports = app