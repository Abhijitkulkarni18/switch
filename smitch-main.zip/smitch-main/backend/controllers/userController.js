const User = require('../models/user');
const Device = require('../models/device');

const ErrorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middlewares/catchAsyncErrors');
const sendToken = require('../utils/jwtToken');


exports.userLogin = catchAsyncErrors(async (req, res, next) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return next(new ErrorHandler('Please enter email & password', 400))
    }
    const user = await User.findOne({ email }).select('+password')
    if (!user) {
        return next(new ErrorHandler('Account with this Email ID does not exists', 400));
        // const userCreate = await User.create({ email, password })
        // sendToken(userCreate, 200, res, message='Signup succcessful')
    } else{
        const isPasswordMatched = await user.comparePassword(password);
        if (!isPasswordMatched) {
            return next(new ErrorHandler('Invalid Password', 400));
        }
        sendToken(user, 200, res, message='Login succcessful')
    }
})


exports.userSignup = catchAsyncErrors(async (req, res, next) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return next(new ErrorHandler('Please enter email & password', 400))
    }
    const user = await User.findOne({ email }).select('+password')
    if (user) {
        return next(new ErrorHandler('Account with this Email ID already exists', 400));
        // const userCreate = await User.create({ email, password })
        // sendToken(userCreate, 200, res, message='Signup succcessful')
    } else{
        const userCreate = await User.create({ email, password })
        sendToken(userCreate, 200, res, message='Signup succcessful')
        // const isPasswordMatched = await user.comparePassword(password);
        // if (!isPasswordMatched) {
        //     return next(new ErrorHandler('Invalid Password', 400));
        // }
        // sendToken(user, 200, res, message='Login succcessful')
    }
})

exports.shareDevice = catchAsyncErrors(async (req, res, next) => {
    await User.findOneAndUpdate({email: req.query.email}, {$push: {devices: req.body.deviceId}}) 
    res.status(200).json({
        success: true
    })
})

exports.getUsers = catchAsyncErrors(async (req, res, next) => {
    const users = await User.find({ _id : { $ne: req.user.id }, devices: { $exists: true, $ne: req.query.deviceId }}) 
    res.status(200).json({
        success: true,
        users
    })
})