const Device = require('../models/device');
const User = require('../models/user');
const redis = require('redis');

const ErrorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middlewares/catchAsyncErrors');

const client = redis.createClient({
    port      : 6379,
    host      : 'redis'
});


exports.createDevice = catchAsyncErrors(async (req, res, next) => {
    const { name, devType, currentState } = req.body;
    const device = await Device.create({ name, devType, currentState })
    await User.findByIdAndUpdate(req.user.id, {$push: {devices: device.id}}) 
    client.del(req.user.id);
    res.status(200).json({
        success: true, device
    })
})


exports.getSingleDevice = catchAsyncErrors(async (req, res, next) => {
    const device = await Device.findById(req.params.id)
    if (!device) {
        return next(new ErrorHandler('No Device found with this ID', 404))
    }
    res.status(200).json({
        success: true,
        device
    })
})

exports.getDevice = catchAsyncErrors(async (req, res, next) => {
    const devices = await Device.find({ _id : { $in: req.user.devices }})
    console.log('data from db')
    client.setex(req.user.id, 60, JSON.stringify(devices));
    res.status(200).json({
        success: true,
        devices
    })
})

exports.editDevice = catchAsyncErrors(async (req, res, next) => {
    const data = req.body;
    const device = await Device.findById(req.params.id)
    if (!device) {
        return next(new ErrorHandler('No Device found with this ID', 404))
    }
    if (data.currentState !==  device.currentState){
        data['lastUpdated'] = Date.now()
    }
    await device.updateOne(data)
    // We can use background process to reset the cache
    client.del(req.user.id);
    res.status(200).json({
        success: true,
    })
})

exports.updateState = catchAsyncErrors(async (req, res, next) => {
    const device = await Device.findById(req.params.id)
    if (!device) {
        return next(new ErrorHandler('No Device found with this ID', 404))
    }
    await device.updateOne({lastUpdated: Date.now(), currentState: req.body.currentState})
    // We can use background process to reset the cache
    client.del(req.user.id);
    res.status(200).json({
        success: true,
    })
})

exports.deleteDevice = catchAsyncErrors(async (req, res, next) => {
    const device = await Device.findById(req.params.id)
    if (!device) {
        return next(new ErrorHandler('No Device found with this ID', 404))
    }
    // We can use background process to reset the cache and update user
    await User.updateMany({}, { $pull: { devices: req.params.id } })
    client.del(req.user.id);
    await device.remove()
    res.status(200).json({
        success: true
    })
})