const mangoose = require('mongoose');

const connectDatabase = () => {
    // const url = 'mongodb+srv://smitch:passsmitch@smitch.htjtb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
    const url = 'mongodb://mongo:27017/device'
    mangoose.connect(url,{
        useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true
    }).then(con => {
        console.log('connected to mongodb')
    })
}

module.exports = connectDatabase;