const mongoose = require('mongoose');

const deviceSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please enter Device name'],
        trim: true,
        maxLength: [100, 'Device name cannot exceed 100 characters']
    },
    devType: {
        type: String,
        required: [true, 'Please select devType for this device'],
        enum: {
            values: [
                'AA',
                'AB',
                'AC',
                'BA',
                'BB',
                'BC'
            ],
            message: 'Please select correct devType for device'
    }},
    currentState: {
        type: Boolean,
        required: [true, 'Please enter Device name'],
    },
    lastUpdated: {
        type: Date,
        default: Date.now
    }
    }
,{
    toJSON: {
      transform(doc, ret) {
        delete ret.__v;
        ret.lastUpdated = Math.floor(ret.lastUpdated.getTime()/ 1000)
},
}}
)

module.exports = mongoose.model('Device', deviceSchema);