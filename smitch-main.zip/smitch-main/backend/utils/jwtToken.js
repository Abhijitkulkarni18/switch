const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET || 'jnsdcdjcnjwncwjnjvervjevjervjerjvne'
const JWT_EXPIRES_TIME = process.env.JWT_EXPIRES_TIME || 24 * 60 * 60 * 1000

const sendToken = (user, statusCode, res, message) => {
    const token = jwt.sign({ id: user.id }, JWT_SECRET, {
        expiresIn: JWT_EXPIRES_TIME
    });
    res.status(statusCode).json({
        success: true,
        token,
        user,
        message
    })

}

module.exports = sendToken;