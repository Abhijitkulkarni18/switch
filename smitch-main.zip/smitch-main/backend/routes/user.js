const express = require('express');
const router = express.Router();

const { userLogin, shareDevice, getUsers, userSignup } = require('../controllers/userController.js');
const { isAuthenticatedUser } = require('../middlewares/auth');

router.route('/login').post(userLogin);

router.route('/signup').post(userSignup);

router.route('/share').post(isAuthenticatedUser, shareDevice);

router.route('/users').get(isAuthenticatedUser, getUsers);

module.exports = router;