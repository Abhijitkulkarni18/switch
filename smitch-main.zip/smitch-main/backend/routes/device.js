const express = require('express');
const router = express.Router();
const {validate} = require('express-validation');

const { createDevice, editDevice, getDevice, deleteDevice, getSingleDevice, updateState } = require('../controllers/deviceController.js');
const { isAuthenticatedUser } = require('../middlewares/auth');
const { cache } = require('../middlewares/cache');

const deviceValidation = require('../validator.js');

router.route('/device').get(isAuthenticatedUser, cache, getDevice)
                       .post(isAuthenticatedUser,validate(deviceValidation.createDeviceValidation), createDevice)

router.route('/device/:id')
                    .get(isAuthenticatedUser, getSingleDevice)
                    .put(isAuthenticatedUser,validate(deviceValidation.createDeviceValidation), editDevice)
                    .delete(isAuthenticatedUser, deleteDevice)

router.route('/devicestate/:id')
                    .put(isAuthenticatedUser, updateState)

module.exports = router;