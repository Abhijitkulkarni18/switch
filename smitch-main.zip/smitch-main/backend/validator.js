const { Joi } = require("express-validation");

module.exports = {
    createDeviceValidation: {
      body: Joi.object({
        name: Joi.string().required().messages({
          'string': `name must be a string`
        }),
        devType: Joi.string().required().messages({
            'string': `devType must be a string`
          }),
        currentState: Joi.boolean().messages({
          'boolean': `currentStatus must be Boolean`
        })
      })
    },
}