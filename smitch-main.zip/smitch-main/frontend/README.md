React App:

To install packages:
npm install

To start the server:
npm start