import React, { useState } from 'react';
import './login.css';
import api from '../api'


const Login = ({ setToken }) =>  {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();

  const [signUp, setSignUp] = useState(true);

  const handleSubmit = async e => {
    e.preventDefault();
    if (signUp){
      await api.Signup({ email, password })
      .then(res => {
        localStorage.setItem('token',res.data.token)
        setToken(res.data.token)
        window.location.reload()
      })
      .catch(error => {
        console.log(error.response.data.message)
        window.alert(error.response.data.message)
        });
    } else{
      await api.Login({ email, password })
      .then(res => {
        localStorage.setItem('token',res.data.token)
        setToken(res.data.token)
        window.location.reload()
      })
      .catch(error => {
        console.log(error.response.data.message)
        window.alert(error.response.data.message)
        });
    }
  }
  const swithAuthModeHandler = (event) => {
    event.preventDefault();
    setSignUp(!signUp);
}

  return(
    <div className="form-group login-wrapper">
      <h1>Welcome to SMITCH</h1>
      <h2>{signUp ? 'Sign Up' : 'LogIn'}</h2>
      <form onSubmit={handleSubmit}>
      <div className="form-group">
          <p>Email</p>
          <input className="form-control" type="email" id="email" placeholder='Your Email' required onChange={e => setEmail(e.target.value)}/>
      </div>
      <div className="form-group">
        <p>Password</p>
          <input className="form-control" type="password" placeholder='Your Password' onChange={e => setPassword(e.target.value)}/>
      </div>
        <div>
          <button className="btn btn-primary btn-block" type="submit">{signUp ? 'Sign Up' : 'LogIn'}</button>
        </div>
      </form>
        <div>
          <button className="btn btn-info" style={{margin: '20px', padding: '0 20'}} onClick={swithAuthModeHandler}>Switch to {signUp ? 'LogIn' : 'Sign Up'}</button>
        </div>
    </div>
  )
}

export default Login;