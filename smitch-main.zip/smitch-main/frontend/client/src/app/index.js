import React, { useState } from 'react'
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom'

import { NavBar } from '../components'
import { DeviceList, DeviceInsert, DeviceUpdate, DeviceShare } from '../pages'
import Login from '../Auth/login';
import Logout from '../Auth/logout';

import 'bootstrap/dist/css/bootstrap.min.css'

const  App = () => {
    const [token, setToken] = useState();

    if (!token && localStorage.getItem('token')){
        setToken(localStorage.getItem('token'))
    }

    if(!token) {
        return (
            <Router>
                <Switch>
                    <Route path="/" exact><Login setToken={setToken} /></Route>
                    <Redirect to="/" />;
                </Switch>
            </Router>
        )
    }
    
    return (
        <Router>
            <NavBar />
            <Switch>
                <Route path="/device/list" exact component={DeviceList} />
                <Route path="/device/create" exact component={DeviceInsert} />
                <Route
                    path="/device/update/:id"
                    exact
                    component={DeviceUpdate}
                />
                <Route
                    path="/device/share/:id"
                    exact
                    component={DeviceShare}
                />
                <Route
                    path="/logout"
                    exact
                    component={Logout}
                />
                <Redirect to="/device/list" />;
            </Switch>
        </Router>
    )
}

export default App