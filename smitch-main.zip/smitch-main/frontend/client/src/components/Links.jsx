import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import styled from 'styled-components'

const Collapse = styled.div.attrs({
    className: 'collpase navbar-collapse',
})``

const List = styled.div.attrs({
    className: 'navbar-nav mr-auto',
})``

const ListRight = styled.div.attrs({
    className: 'navbar-nav ml-auto btn btn-outline-danger',
})``

const Item = styled.div.attrs({
    className: 'collpase navbar-collapse',
})``

class Links extends Component {
    render() {
        return (
            <React.Fragment>
                {/* <Link to="/" className="navbar-brand">
                    Devices
                </Link> */}
                <Collapse>
                    <List>
                        <Item>
                            <Link to="/device/list" className="nav-link" >
                                List Device
                            </Link>
                        </Item>
                        <Item>
                            <Link to="/device/create" className="nav-link">
                                Create Device
                            </Link>
                        </Item>
                    </List>
                    <ListRight>
                        <Item>
                            <Link to="/logout" className="nav-link">
                                Logout
                            </Link>
                        </Item>
                    </ListRight>
                </Collapse>
            </React.Fragment>
        )
    }
}

export default Links