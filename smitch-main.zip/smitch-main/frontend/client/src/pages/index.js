import DeviceList from './DeviceList'
import DeviceInsert from './DeviceInsert'
import DeviceUpdate from './DeviceUpdate'
import DeviceShare from './DeviceShare'

export { DeviceList, DeviceInsert, DeviceUpdate, DeviceShare }