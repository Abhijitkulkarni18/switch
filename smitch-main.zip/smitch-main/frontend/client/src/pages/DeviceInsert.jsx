import React, { Component } from 'react'
import api from '../api'

import styled from 'styled-components'

const Title = styled.h1.attrs({
    className: 'h1',
})``

const Wrapper = styled.div.attrs({
    className: 'form-group',
})`
    margin: 0 30px;
`

const Label = styled.label`
    margin: 5px;
`

const InputText = styled.input.attrs({
    className: 'form-control',
})`
    margin: 5px;
`

const Button = styled.button.attrs({
    className: `btn btn-primary`,
})`
    margin: 15px 15px 15px 5px;
`

const CancelButton = styled.a.attrs({
    className: `btn btn-danger`,
})`
    margin: 15px 15px 15px 5px;
`

const CheckBoxWrapper = styled.div`
  position: relative;
`;
const CheckBoxLabel = styled.label`
  position: absolute;
  top: 0;
  left: 0;
  width: 42px;
  height: 26px;
  border-radius: 15px;
  background: #bebebe;
  cursor: pointer;
  &::after {
    content: "";
    display: block;
    border-radius: 50%;
    width: 18px;
    height: 18px;
    margin: 3px;
    background: #ffffff;
    box-shadow: 1px 3px 3px 1px rgba(0, 0, 0, 0.2);
    transition: 0.2s;
  }
`;
const CheckBox = styled.input`
  opacity: 0;
  z-index: 1;
  border-radius: 15px;
  width: 42px;
  height: 26px;
  &:checked + ${CheckBoxLabel} {
    background: #4fbe79;
    &::after {
      content: "";
      display: block;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      margin-left: 21px;
      transition: 0.2s;
    }
  }
`;

class DeviceInsert extends Component {
    constructor(props) {
        super(props)

        this.state = {
            name: '',
            devType: 'AA',
            currentState: false,
        }
    }

    handleChangeInputName = async event => {
        const name = event.target.value
        this.setState({ name })
    }

    handleChangeInputDevType = async event => {
        const devType = event.target.validity.valid
            ? event.target.value
            : this.state.devType

        this.setState({ devType })
    }

    handleChangeCurrentState = async event => {
        const currentState = this.state.currentState ? false : true
        this.setState({ currentState })
    }

    handleIncludeDevice = async () => {
        const { name, devType, currentState } = this.state
        const payload = { name, devType, currentState }

        await api.insertDevice(payload).then(res => {
            window.alert(`Device inserted successfully`)
            this.setState({
                name: '',
                devType: '',
                currentState: false,
            })
        })
        .catch(error => {
            console.log(error.response.data?.message)
            window.alert(error.response.data?.message)
            });
    }

    render() {
        const { name, devType, currentState } = this.state
        return (
            <Wrapper>
                <Title>Create Device</Title>
                <Label>Name: </Label>
                <InputText
                    type="text"
                    value={name}
                    onChange={this.handleChangeInputName}
                />
                <Label>Dev Type: </Label>
                <div>
                    <select value={devType} onChange={this.handleChangeInputDevType}>
                                    <option key='AA' value='AA'>AA</option>
                                    <option key='AB' value='AB'>AB</option>
                                    <option key='AC' value='AC'>AC</option>
                                    <option key='BA' value='BA'>BA</option>
                                    <option key='BB' value='BB'>BB</option>
                                    <option key='BC' value='BC'>BC</option>
                    </select>
                </div>
                <Label>Current State: </Label>
                <div>
                    <CheckBoxWrapper>
                        <CheckBox id="checkbox" type="checkbox" checked={currentState} onChange={this.handleChangeCurrentState}/>
                        {currentState ? 'ON': 'OFF'}
                        <CheckBoxLabel htmlFor="checkbox" />
                    </CheckBoxWrapper>
                </div>
                <Button onClick={this.handleIncludeDevice}>Add Device</Button>
                <CancelButton href={'/device/list'}>Cancel</CancelButton>
            </Wrapper>
        )
    }
}

export default DeviceInsert