import React, { Component } from 'react'
import ReactTable from 'react-table'
import api from '../api'

import styled from 'styled-components'

import 'react-table/react-table.css'

const Wrapper = styled.div`
    padding: 0 40px 40px 40px;
    margin: 20px
`

const Update = styled.div`
    color: #ef9b0f;
    cursor: pointer;
`

const Share = styled.div`
    color: #228B22;
    cursor: pointer;
`

const Delete = styled.div`
    color: #ff0000;
    cursor: pointer;
`
const CheckBoxWrapper = styled.div`
  position: relative;
`;
const CheckBoxLabel = styled.label`
  position: absolute;
  top: 0;
  left: 0;
  width: 42px;
  height: 26px;
  border-radius: 15px;
  background: #bebebe;
  cursor: pointer;
  &::after {
    content: "";
    display: block;
    border-radius: 50%;
    width: 18px;
    height: 18px;
    margin: 3px;
    background: #ffffff;
    box-shadow: 1px 3px 3px 1px rgba(0, 0, 0, 0.2);
    transition: 0.2s;
  }
`;
const CheckBox = styled.input`
  opacity: 0;
  z-index: 1;
  border-radius: 15px;
  width: 42px;
  height: 26px;
  &:checked + ${CheckBoxLabel} {
    background: #4fbe79;
    &::after {
      content: "";
      display: block;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      margin-left: 21px;
      transition: 0.2s;
    }
  }
`;

class UpdateDevice extends Component {
    updateUser = event => {
        event.preventDefault()

        window.location.href = `/device/update/${this.props.id}`
    }

    render() {
        return <Update onClick={this.updateUser}>Update</Update>
    }
}

class ShareDevice extends Component {
    shareUser = event => {
        event.preventDefault()

        window.location.href = `/device/share/${this.props.id}`
    }

    render() {
        return <Share onClick={this.shareUser}>Share</Share>
    }
}

class UpdateCurrentStatus extends Component {
    render() {
        console.log(this.props)
        return (    <CheckBoxWrapper>
                        <CheckBox id="checkbox" type="checkbox" checked={this.props.currentState} disabled={true}/>
                        {this.props.currentState ? 'ON': 'OFF'}
                        <CheckBoxLabel htmlFor="checkbox" />
                    </CheckBoxWrapper>)
    }
}

class DeleteDevice extends Component {
    deleteUser = async event => {
        event.preventDefault()

        if (
            window.confirm(
                `Do tou want to delete the device ${this.props.id} permanently?`,
            )
        ) {
            await api.deleteDeviceById(this.props.id)
            window.location.reload()
        }
    }

    render() {
        return <Delete onClick={this.deleteUser}>Delete</Delete>
    }
}



class DevicesList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            devices: [],
            columns: [],
            isLoading: false,
        }
    }

    componentDidMount = async () => {
        this.setState({ isLoading: true })

        await api.getAllDevices().then(res => {
            this.setState({
                devices: res.data.devices,
                isLoading: false,
            })
        })
        .catch(error => {
            console.log(error)
            });
    }

    render() {
        const { devices, isLoading } = this.state
        console.log('TCL: DevicesList -> render -> devices', devices)

        const columns = [
            {
                Header: 'ID',
                accessor: '_id',
                Cell: row => <div style={{ textAlign: "center" }}>{row.value}</div>
            },
            {
                Header: 'Name',
                accessor: 'name',
                Cell: row => <div style={{ textAlign: "center" }}>{row.value}</div>
            },
            {
                Header: 'Dev Type',
                accessor: 'devType',
                Cell: row => <div style={{ textAlign: "center" }}>{row.value}</div>
            },
            {
                Header: 'Current State',
                accessor: 'currentState',
                Cell: function(props) {
                    return (
                        <span>
                            <UpdateCurrentStatus id={props.original._id} currentState={props.original.currentState} />
                        </span>
                    )
                },
            },
            {
                Header: 'Last Updated',
                accessor: 'lastUpdated',
                Cell: row => <div style={{ textAlign: "center" }}>{row.value}</div>
            },
            {
                Header: '',
                accessor: '',
                Cell: function(props) {
                    return (
                        <span>
                            <DeleteDevice id={props.original._id} />
                        </span>
                    )
                },
            },
            {
                Header: '',
                accessor: '',
                Cell: function(props) {
                    return (
                        <span>
                            <UpdateDevice id={props.original._id} />
                        </span>
                    )
                },
            },
            {
                Header: '',
                accessor: '',
                Cell: function(props) {
                    return (
                        <span>
                            <ShareDevice id={props.original._id} />
                        </span>
                    )
                },
            },
        ]

        let showTable = true
        if (!devices.length) {
            showTable = false
        }

        return (
            <Wrapper>
                {showTable && (
                    <ReactTable
                        data={devices}
                        columns={columns}
                        loading={isLoading}
                        defaultPageSize={10}
                        showPaginationBottom={false}
                        showPageSizeOptions={false}
                        minRows={0}
                    />
                )}
            </Wrapper>
        )
    }
}

export default DevicesList