import axios from 'axios'

const baseURL = 'http://localhost:8000/api'

// If hosting on remote server, comment the above line and update your baseURL below.
// const baseURL = 'http://3.86.39.139:8000/api'

const api = axios.create({
    baseURL: baseURL,
})
export const Login = payload => api.post(`/login`, payload)
export const Signup = payload => api.post(`/signup`, payload)

api.defaults.headers.common['Authorization'] = 'Bearer '+localStorage.getItem('token');
export const insertDevice = payload => api.post(`/device`, payload)
export const getAllDevices = () => api.get(`/device`)
export const updateDeviceById = (id, payload) => api.put(`/device/${id}`, payload)
export const updateDeviceStateById = (id, payload) => api.put(`/devicestate/${id}`, payload)
export const deleteDeviceById = id => api.delete(`/device/${id}`)
export const getDeviceById = id => api.get(`/device/${id}`)
export const getUsers = id => api.get(`/users?deviceId=${id}`)
export const shareDeviceById = (id, payload) => api.post(`/share?email=${id}`, payload)

const apis = {
    insertDevice,
    getAllDevices,
    updateDeviceById,
    deleteDeviceById,
    getDeviceById,
    getUsers,
    shareDeviceById,
    Login,
    Signup,
    updateDeviceStateById
}

export default apis